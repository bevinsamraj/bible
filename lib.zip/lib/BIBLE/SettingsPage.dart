// lib/BIBLE/SettingsPage.dart
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Assuming AppColors is defined elsewhere in your project
class AppColors {
  static const Color primaryColor = Color(0xFF37474F); // Darker Grey-Blue
  static const Color secondaryColor = Color(0xFF00695C); // Darker Teal
  static const Color accentColor = Color(0xFF4DB6AC); // Light Green
  static const Color backgroundColor = Color(0xFF37474F); // Darker Grey-Blue
  static const Color overlayColor = Colors.grey; // For overlays
  static const Color white = Colors.white;
  static const Color white70 = Colors.white70;
  static const Color titleLargeColor = Color(0xFFB2FF59); // Example light green
}

class SettingsPage extends StatefulWidget {
  final double fontSize;
  final Color fontColor;
  final bool isDarkTheme;
  final Color? backgroundColor;
  final Function(double) onFontSizeChanged;
  final Function(Color) onFontColorChanged;
  final Function(bool) onThemeChanged;
  final Function(Color?) onBackgroundColorChanged;

  SettingsPage({
    required this.fontSize,
    required this.fontColor,
    required this.isDarkTheme,
    required this.backgroundColor,
    required this.onFontSizeChanged,
    required this.onFontColorChanged,
    required this.onThemeChanged,
    required this.onBackgroundColorChanged,
  });

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late double _fontSize;
  late Color _fontColor;
  late bool _isDarkTheme;
  Color? _backgroundColor;

  @override
  void initState() {
    super.initState();
    _fontSize = widget.fontSize;
    _fontColor = widget.fontColor;
    _isDarkTheme = widget.isDarkTheme;
    _backgroundColor = widget.backgroundColor;
  }

  @override
  Widget build(BuildContext context) {
    // Determine whether to use background color or image
    bool useBackgroundColor = _backgroundColor != null;

    // Determine background image based on theme
    String bgImageUrl = _isDarkTheme
        ? 'https://static.vecteezy.com/system/resources/previews/001/217/366/non_2x/polygonal-blue-background-vector.jpg'
        : 'https://c4.wallpaperflare.com/wallpaper/346/806/481/low-poly-abstract-blue-digital-art-wallpaper-preview.jpg';

    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
        backgroundColor: AppColors.primaryColor,
      ),
      body: Stack(
        children: [
          // Background: either solid color or image with blur
          useBackgroundColor
              ? Container(
                  color: _backgroundColor,
                )
              : Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage(bgImageUrl),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 15.0, sigmaY: 15.0),
                    child: Container(
                      color: Colors.black.withOpacity(0.3), // Darken overlay
                    ),
                  ),
                ),
          // Settings Content
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  // Font Size Slider
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Font Size',
                        style: TextStyle(color: AppColors.white, fontSize: 18),
                      ),
                      Text(
                        _fontSize.toInt().toString(),
                        style: TextStyle(color: AppColors.white, fontSize: 18),
                      ),
                    ],
                  ),
                  Slider(
                    value: _fontSize,
                    min: 12.0,
                    max: 30.0,
                    divisions: 18,
                    label: _fontSize.toInt().toString(),
                    activeColor: AppColors.accentColor,
                    inactiveColor: AppColors.white70,
                    onChanged: (double value) {
                      setState(() {
                        _fontSize = value;
                      });
                      widget.onFontSizeChanged(value);
                    },
                  ),
                  SizedBox(height: 20),
                  // Font Color Picker
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Font Color',
                        style: TextStyle(color: AppColors.white, fontSize: 18),
                      ),
                      Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: _fontColor,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.white70),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Wrap(
                    spacing: 10,
                    children: [
                      _colorOption(Colors.white),
                      _colorOption(Colors.yellow),
                      _colorOption(Colors.blue),
                      _colorOption(Colors.green),
                      _colorOption(Colors.red),
                      _colorOption(Colors.orange),
                      _colorOption(Colors.purple),
                      _colorOption(Colors.grey),
                    ],
                  ),
                  SizedBox(height: 20),
                  // Background Color Picker
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Background Color',
                        style: TextStyle(color: AppColors.white, fontSize: 18),
                      ),
                      Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: _backgroundColor ?? Colors.transparent,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.white70),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Wrap(
                    spacing: 10,
                    children: [
                      _backgroundColorOption(Colors.white),
                      _backgroundColorOption(Colors.yellow),
                      _backgroundColorOption(Colors.blue),
                      _backgroundColorOption(Colors.green),
                      _backgroundColorOption(Colors.red),
                      _backgroundColorOption(Colors.orange),
                      _backgroundColorOption(Colors.purple),
                      _backgroundColorOption(Colors.grey),
                      // Option to clear background color
                      _backgroundColorOption(null, label: 'Default'),
                    ],
                  ),
                  SizedBox(height: 30),
                  // Theme Toggle
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Dark Theme',
                        style: TextStyle(color: AppColors.white, fontSize: 18),
                      ),
                      Switch(
                        value: _isDarkTheme,
                        activeColor: AppColors.accentColor,
                        inactiveThumbColor: AppColors.accentColor,
                        onChanged: (bool value) {
                          setState(() {
                            _isDarkTheme = value;
                          });
                          widget.onThemeChanged(value);
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _colorOption(Color color) {
    bool isSelected = _fontColor == color;
    return GestureDetector(
      onTap: () {
        setState(() {
          _fontColor = color;
        });
        widget.onFontColorChanged(color);
      },
      child: Container(
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: isSelected
              ? Border.all(color: AppColors.accentColor, width: 3)
              : null,
        ),
        width: 30,
        height: 30,
      ),
    );
  }

  Widget _backgroundColorOption(Color? color, {String? label}) {
    bool isSelected = _backgroundColor == color;
    return GestureDetector(
      onTap: () {
        setState(() {
          _backgroundColor = color;
        });
        widget.onBackgroundColorChanged(color);
      },
      child: Container(
        padding: label != null ? EdgeInsets.symmetric(horizontal: 4.0) : null,
        decoration: BoxDecoration(
          color: color ?? Colors.transparent,
          shape: BoxShape.circle,
          border: isSelected
              ? Border.all(color: AppColors.accentColor, width: 3)
              : Border.all(color: AppColors.white70, width: 1),
        ),
        width: 30,
        height: 30,
        child: label != null
            ? Text(
                label[0],
                style: TextStyle(
                  color: color != null ? AppColors.primaryColor : AppColors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              )
            : null,
      ),
    );
  }
}
