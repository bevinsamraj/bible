// lib/BIBLE/BibleReaderHome.dart

import 'dart:ui';
import 'package:bible/BIBLE/SettingsPage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For rootBundle
import 'package:xml/xml.dart' as xml;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart'; // For sharing
import 'package:flutter_tts/flutter_tts.dart'; // For Text-to-Speech
import 'VerseSearchDelegate.dart'; // Import the separate search delegate
import 'SavedReferencesPage.dart'; // Import the saved references page

class AppColors {
  // Light Theme Colors
  static const Color lightTextColor = Colors.black;
  static const Color lightBibleNameColor =
      Color.fromARGB(255, 5, 5, 5); // Dark Text
  static const Color lightIconColor = Color(0xFF2196F3); // Blue

  // Dark Theme Colors
  static const Color darkTextColor = Color.fromARGB(255, 255, 255, 255);
  static const Color darkBibleNameColor = Colors.white;
  static const Color darkIconColor = Colors.white;

  // Common Colors
  static const Color secondaryColor = Color(0xFF2196F3); // Light Blue
  static const Color accentColor = Color(0xFF1976D2); // Darker Blue
  static const Color darkPrimaryColor =
      Color(0xFF0D47A1); // Dark Blue for dark theme
  static const Color overlayColor = Colors.grey; // For overlays
  static const Color white70 = Colors.white70;
  static const Color titleLargeColor = Color(0xFF2196F3);

  static const Color darkAccentTextColor = Colors.white;
  static const Color lightAccentTextColor = Color.fromARGB(255, 2, 5, 46);
}

class AppGradients {
  // Light Theme Gradient: Light Blue to White
  static const LinearGradient lightThemeGradient = LinearGradient(
    colors: [
      Color.fromARGB(255, 148, 199, 240), // Light Blue
      Colors.white, // White
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Dark Theme Gradient: Light Blue to Dark Blue
  static const LinearGradient darkThemeGradient = LinearGradient(
    colors: [
      Color.fromARGB(255, 3, 88, 163), // Light Blue
      Color.fromARGB(255, 26, 29, 34), // Dark Blue
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Tile Gradient for Chapters
  static const LinearGradient tileGradient = LinearGradient(
    colors: [
      Color(0xFF2196F3), // Light Blue
      Color(0xFF1976D2), // Darker Blue
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class BibleReaderHome extends StatefulWidget {
  @override
  _BibleReaderHomeState createState() => _BibleReaderHomeState();
}

class _BibleReaderHomeState extends State<BibleReaderHome> {
  final List<BibleVersion> bibleVersions = [
    BibleVersion(name: 'Tamil Bible', filePath: 'assets/bible/Tamil Bible.xml'),
    BibleVersion(
        name: 'New King James Version',
        filePath: 'assets/bible/New King James Version (1982).xml'),
    BibleVersion(name: 'Combined', filePath: 'assets/bible/Bible.xml'),
    BibleVersion(
        name: 'English Standard Version', filePath: 'assets/bible/esv.xml'),
    BibleVersion(
        name: 'Revised Standard Version', filePath: 'assets/bible/rsv.xml'),
  ];

  xml.XmlDocument? bibleXml;
  List<xml.XmlElement> books = [];
  String bibleName = '';
  int currentBibleIndex = 0;
  int currentBookIndex = 0;
  int currentChapterIndex = 0;
  String selectedBookName = '';
  String selectedChapterNumber = '';
  String selectedChapterDisplay = '';
  int totalChapters = 0;
  int totalVerses = 0;
  int totalVersesInBook = 0;
  List<Map<String, String>> savedReferences = [];
  Set<String> bookmarkedReferences = {};

  // Settings variables
  double fontSize = 16.0;
  bool isDarkTheme = false;

  int _selectedIndex = 0;
  String? highlightedReference;

  // Text-to-Speech instance
  final FlutterTts flutterTts = FlutterTts();

  // Scroll Controller for Chapter Details
  final ScrollController _chapterScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    loadSettings();
    loadSavedReferences();
    loadXmlFile(currentBibleIndex);
    initTts();
  }

  Future<void> initTts() async {
    flutterTts.setCompletionHandler(() {
      // Handle completion if needed
    });
    flutterTts.setErrorHandler((msg) {
      // Handle error if needed
    });
    // Optionally, set default voice parameters here
  }

  Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      fontSize = prefs.getDouble('fontSize') ?? 16.0;
      isDarkTheme = prefs.getBool('isDarkTheme') ?? false;
    });
  }

  Future<void> saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('fontSize', fontSize);
    await prefs.setBool('isDarkTheme', isDarkTheme);
  }

  Future<void> loadXmlFile(int bibleIndex) async {
    try {
      final fileName = bibleVersions[bibleIndex].filePath;
      final xmlData = await rootBundle.loadString(fileName);
      setState(() {
        currentBibleIndex = bibleIndex;
        bibleXml = xml.XmlDocument.parse(xmlData);
        bibleName = bibleVersions[bibleIndex].name;
        books = bibleXml!.findAllElements('BIBLEBOOK').toList();
        if (books.isNotEmpty) {
          loadBook(0); // Load first book by default
        } else {
          books = [];
          selectedBookName = '';
          selectedChapterNumber = '';
          selectedChapterDisplay = '';
        }
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load Bible version')),
      );
    }
  }

  void loadBook(int index) {
    setState(() {
      currentBookIndex = index;
      var book = books[index];

      // Handle book name based on the Bible version
      if (bibleName == 'Combined') {
        selectedBookName =
            '${book.getAttribute('bname_en') ?? 'Unknown Book'} / ${book.getAttribute('bname_ta') ?? 'Unknown Book'}';
      } else if (bibleName == 'Tamil Bible') {
        // Use 'bname' attribute for Tamil Bible
        selectedBookName = book.getAttribute('bname') ??
            'புத்தகம் தெரியவில்லை'; // Tamil fallback
      } else {
        selectedBookName = book.getAttribute('bname') ?? 'Unknown Book';
      }

      var chapters = book.findAllElements('CHAPTER').toList();
      totalChapters = chapters.length;

      if (chapters.isNotEmpty) {
        loadChapter(0); // Load the first chapter
      } else {
        selectedChapterNumber = '';
        selectedChapterDisplay = '';
      }
    });
  }

  void loadChapter(int index) {
    setState(() {
      currentChapterIndex = index;
      var chapters =
          books[currentBookIndex].findAllElements('CHAPTER').toList();
      var verses = chapters[index].findAllElements('VERS').toList();
      totalVersesInBook =
          books[currentBookIndex].findAllElements('VERS').length;
      totalVerses = verses.length;

      selectedChapterNumber = chapters[index].getAttribute('cnumber') ?? '';
      selectedChapterDisplay = 'Chapter ${currentChapterIndex + 1}';
      // Reset highlighted verse if navigating to a different chapter
      if (highlightedReference != null &&
          !highlightedReference!.contains(':$selectedChapterNumber:')) {
        highlightedReference = null;
      }
    });
  }

  Future<void> saveReference(String reference) async {
    final prefs = await SharedPreferences.getInstance();
    if (!bookmarkedReferences.contains(reference)) {
      savedReferences
          .add({'reference': reference, 'date': DateTime.now().toString()});
      bookmarkedReferences.add(reference);
      List<String> savedReferencesString = savedReferences
          .map((e) => "${e['reference']}::${e['date']}")
          .toList();
      await prefs.setStringList('savedReferences', savedReferencesString);
      setState(() {});
    }
  }

  Future<void> removeReference(String reference) async {
    final prefs = await SharedPreferences.getInstance();
    savedReferences.removeWhere((e) => e['reference'] == reference);
    bookmarkedReferences.remove(reference);
    List<String> savedReferencesString =
        savedReferences.map((e) => "${e['reference']}::${e['date']}").toList();
    await prefs.setStringList('savedReferences', savedReferencesString);
    setState(() {});
  }

  Future<void> loadSavedReferences() async {
    final prefs = await SharedPreferences.getInstance();
    List<String>? savedReferencesString =
        prefs.getStringList('savedReferences');
    if (savedReferencesString != null) {
      savedReferences = savedReferencesString.map((e) {
        List<String> parts = e.split("::");
        return {'reference': parts[0], 'date': parts[1]};
      }).toList();
      bookmarkedReferences =
          savedReferences.map((e) => e['reference']!).toSet();
    }
    setState(() {});
  }

  void _startSearch() {
    showSearch(
      context: context,
      delegate: VerseSearchDelegate(
        books: books,
        onSaveReference: saveReference,
        bibleName: bibleName,
        fontSize: fontSize,
        fontColor:
            isDarkTheme ? AppColors.darkTextColor : AppColors.lightTextColor,
        onNavigateToVerse: goToVerse,
        isDarkTheme: isDarkTheme,
        // Pass the speak function if needed
      ),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      if (_selectedIndex != 3) {
        highlightedReference = null; // Reset highlight when not on Chapter tab
      }
    });
  }

  void _navigateToSavedReferences() {
    Navigator.of(context).push(
      MaterialPageRoute(
          builder: (context) => SavedReferencesPage(
                savedReferences: savedReferences,
                getVerseDetails: getVerseDetails,
                onGoToVerse: (reference) {
                  Navigator.of(context).pop();
                  goToVerse(reference);
                },
                isDarkTheme: isDarkTheme, // Pass the theme flag
              )),
    );
  }

  void goToVerse(String reference) {
    // Reference format: "BookName Chapter:Verse"
    List<String> parts = reference.split(' ');
    if (parts.length >= 2) {
      String bookNamePart = parts.sublist(0, parts.length - 1).join(' ');
      String chapterAndVerse = parts.last;
      List<String> chapterVerseParts = chapterAndVerse.split(':');
      if (chapterVerseParts.length >= 2) {
        String chapterNumber = chapterVerseParts[0];
        String verseNumber = chapterVerseParts[1];

        for (int i = 0; i < books.length; i++) {
          var book = books[i];
          String currentBookName = '';

          if (bibleName == 'Combined') {
            String enBookName = book.getAttribute('bname_en') ?? '';
            String taBookName = book.getAttribute('bname_ta') ?? '';
            currentBookName = '$enBookName / $taBookName';

            if (currentBookName.contains(bookNamePart)) {
              var chapters = book.findAllElements('CHAPTER').toList();
              for (int j = 0; j < chapters.length; j++) {
                var chapter = chapters[j];
                if (chapter.getAttribute('cnumber') == chapterNumber) {
                  loadBook(i);
                  loadChapter(j);
                  setState(() {
                    _selectedIndex = 3; // Navigate to Chapter Details page
                    highlightedReference = reference;
                  });
                  // Scroll to the verse after a short delay to ensure UI is updated
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _scrollToVerse(reference);
                  });
                  return;
                }
              }
            }
          } else if (bibleName == 'Tamil Bible') {
            String taBookName = book.getAttribute('bname') ?? '';
            currentBookName = taBookName;
            if (currentBookName == bookNamePart) {
              var chapters = book.findAllElements('CHAPTER').toList();
              for (int j = 0; j < chapters.length; j++) {
                var chapter = chapters[j];
                if (chapter.getAttribute('cnumber') == chapterNumber) {
                  loadBook(i);
                  loadChapter(j);
                  setState(() {
                    _selectedIndex = 3; // Navigate to Chapter Details page
                    highlightedReference = reference;
                  });
                  // Scroll to the verse after a short delay to ensure UI is updated
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _scrollToVerse(reference);
                  });
                  return;
                }
              }
            }
          } else {
            String enBookName = book.getAttribute('bname') ?? '';
            currentBookName = enBookName;
            if (currentBookName == bookNamePart) {
              var chapters = book.findAllElements('CHAPTER').toList();
              for (int j = 0; j < chapters.length; j++) {
                var chapter = chapters[j];
                if (chapter.getAttribute('cnumber') == chapterNumber) {
                  loadBook(i);
                  loadChapter(j);
                  setState(() {
                    _selectedIndex = 3; // Navigate to Chapter Details page
                    highlightedReference = reference;
                  });
                  // Scroll to the verse after a short delay to ensure UI is updated
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _scrollToVerse(reference);
                  });
                  return;
                }
              }
            }
          }
        }
      }
    }
  }

  void _scrollToVerse(String reference) {
    // Use a GlobalKey or find the index of the verse to scroll to
    List<String> parts = reference.split(' ');
    if (parts.length >= 2) {
      String chapterAndVerse = parts.last;
      List<String> chapterVerseParts = chapterAndVerse.split(':');
      if (chapterVerseParts.length >= 2) {
        String verseNumber = chapterVerseParts[1];
        int verseIndex = int.tryParse(verseNumber) ?? 0;
        if (verseIndex > 0) {
          // Scroll to the verse using ScrollController
          double position = (verseIndex - 1) * (fontSize + 24);
          _chapterScrollController.animateTo(
            position,
            duration: Duration(milliseconds: 300),
            curve: Curves.easeInOut,
          );
        }
      }
    }
  }

  String getVerseDetails(String reference) {
    // Reference format: "BookName Chapter:Verse"
    List<String> parts = reference.split(' ');
    if (parts.length >= 2) {
      String bookNamePart = parts.sublist(0, parts.length - 1).join(' ');
      String chapterAndVerse = parts.last;
      List<String> chapterVerseParts = chapterAndVerse.split(':');
      if (chapterVerseParts.length >= 2) {
        String chapterNumber = chapterVerseParts[0];
        String verseNumber = chapterVerseParts[1];

        for (var book in books) {
          String currentBookName = '';

          if (bibleName == 'Combined') {
            String enBookName = book.getAttribute('bname_en') ?? '';
            String taBookName = book.getAttribute('bname_ta') ?? '';
            currentBookName = '$enBookName / $taBookName';

            if (currentBookName.contains(bookNamePart)) {
              var chapters = book.findAllElements('CHAPTER').toList();
              for (var chapter in chapters) {
                if (chapter.getAttribute('cnumber') == chapterNumber) {
                  var verse = chapter.findAllElements('VERS').firstWhere(
                      (v) => v.getAttribute('vnumber') == verseNumber,
                      orElse: () => xml.XmlElement(xml.XmlName('VERS')));
                  if (verse.name.local != 'VERS') {
                    continue;
                  }
                  String enText = verse.findElements('EN').isNotEmpty
                      ? verse.findElements('EN').first.text.trim()
                      : '';
                  String taText = verse.findElements('TA').isNotEmpty
                      ? verse.findElements('TA').first.text.trim()
                      : '';
                  return 'NKJV: $enText\nதமிழ்: $taText';
                }
              }
            }
          } else if (bibleName == 'Tamil Bible') {
            String taBookName = book.getAttribute('bname') ?? '';
            currentBookName = taBookName;

            if (currentBookName == bookNamePart) {
              var chapters = book.findAllElements('CHAPTER').toList();
              for (var chapter in chapters) {
                if (chapter.getAttribute('cnumber') == chapterNumber) {
                  var verse = chapter.findAllElements('VERS').firstWhere(
                      (v) => v.getAttribute('vnumber') == verseNumber,
                      orElse: () => xml.XmlElement(xml.XmlName('VERS')));
                  if (verse.name.local != 'VERS') {
                    continue;
                  }
                  String verseText = verse.text.trim();
                  return verseText;
                }
              }
            }
          } else {
            String enBookName = book.getAttribute('bname') ?? '';
            currentBookName = enBookName;

            if (currentBookName == bookNamePart) {
              var chapters = book.findAllElements('CHAPTER').toList();
              for (var chapter in chapters) {
                if (chapter.getAttribute('cnumber') == chapterNumber) {
                  var verse = chapter.findAllElements('VERS').firstWhere(
                      (v) => v.getAttribute('vnumber') == verseNumber,
                      orElse: () => xml.XmlElement(xml.XmlName('VERS')));
                  if (verse.name.local != 'VERS') {
                    continue;
                  }
                  String verseText = verse.text.trim();
                  return verseText;
                }
              }
            }
          }
        }
      }
    }
    return 'No details found';
  }

  bool containsTamil(String text) {
    final tamilRegex = RegExp(r'[\u0B80-\u0BFF]');
    return tamilRegex.hasMatch(text);
  }

  Future<void> _speak(String text, String language) async {
    await flutterTts.setLanguage(language);
    await flutterTts.setPitch(1.0);
    await flutterTts.setSpeechRate(0.5);
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [
      bibleVersionsTab(),
      statsTab(),
      booksTab(),
      chapterDetailsTab(),
    ];

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.accentColor,
        child: Icon(Icons.bookmark,
            color: isDarkTheme
                ? AppColors.darkIconColor
                : AppColors.lightIconColor),
        onPressed: _navigateToSavedReferences,
      ),
      appBar: AppBar(
        title: Text(
          'Bible Reader',
          style: TextStyle(
            fontSize: 24,
            color: isDarkTheme
                ? AppColors.darkTextColor
                : AppColors.lightTextColor, // Dynamic color
          ),
        ),
        actions: [
          if (_selectedIndex == 0 || _selectedIndex == 2 || _selectedIndex == 3)
            IconButton(
              icon: Icon(Icons.search,
                  color: isDarkTheme
                      ? AppColors.darkIconColor
                      : AppColors.lightIconColor),
              onPressed: _startSearch,
            ),
          IconButton(
            icon: Icon(Icons.settings,
                color: isDarkTheme
                    ? AppColors.darkIconColor
                    : AppColors.lightIconColor),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => SettingsPage(
                    fontSize: fontSize,
                    isDarkTheme: isDarkTheme,
                    onFontSizeChanged: (newSize) {
                      setState(() {
                        fontSize = newSize;
                      });
                      saveSettings();
                    },
                    onThemeChanged: (newTheme) {
                      setState(() {
                        isDarkTheme = newTheme;
                      });
                      saveSettings();
                    },
                  ),
                ),
              );
            },
          ),
        ],
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: isDarkTheme
                ? AppGradients.darkThemeGradient
                : AppGradients.lightThemeGradient,
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: isDarkTheme
              ? AppGradients.darkThemeGradient
              : AppGradients.lightThemeGradient,
        ),
        child: Stack(
          children: [
            SafeArea(
              child: _pages.elementAt(_selectedIndex),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: AppColors.secondaryColor,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.menu_book),
            label: 'Versions',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.assessment),
            label: 'Stats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.book),
            label: 'Books',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chrome_reader_mode),
            label: 'Chapter',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: AppColors.lightTextColor,
        unselectedItemColor: AppColors.white70,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }

  Widget bibleVersionsTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            'Select a Bible Version',
            style: TextStyle(
                fontSize: 20,
                color: isDarkTheme
                    ? AppColors.darkAccentTextColor
                    : AppColors.lightAccentTextColor),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(8.0),
            itemCount: bibleVersions.length,
            itemBuilder: (context, index) {
              bool isSelected = currentBibleIndex == index;
              return Card(
                color: isSelected
                    ? AppColors.accentColor.withOpacity(0.8)
                    : AppColors.secondaryColor.withOpacity(0.8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: isSelected
                      ? BorderSide(color: AppColors.accentColor, width: 2)
                      : BorderSide(color: Colors.transparent, width: 0),
                ),
                margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: AppColors.accentColor,
                    child: Icon(
                      Icons.book,
                      color: isDarkTheme
                          ? AppColors.darkIconColor
                          : AppColors.lightIconColor,
                    ),
                  ),
                  title: Text(
                    bibleVersions[index].name,
                    style: TextStyle(
                      fontSize: 18,
                      color: isDarkTheme
                          ? AppColors.darkTextColor
                          : AppColors.lightTextColor,
                      fontWeight:
                          isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                  trailing: isSelected
                      ? Icon(Icons.check_circle, color: AppColors.accentColor)
                      : null,
                  onTap: () async {
                    await loadXmlFile(index);
                    setState(() {
                      _selectedIndex = 1; // Navigate to Stats tab
                    });
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget statsTab() {
    if (books.isEmpty) {
      return Center(
        child: Text(
          'No Bible Version Loaded.',
          style: TextStyle(
              color: isDarkTheme
                  ? AppColors.darkAccentTextColor
                  : AppColors.lightAccentTextColor,
              fontSize: 18),
        ),
      );
    }

    int totalBooks = books.length;
    int totalChapters = books.fold(
        0, (sum, book) => sum + book.findAllElements('CHAPTER').length);
    int totalVerses =
        books.fold(0, (sum, book) => sum + book.findAllElements('VERS').length);
    int totalWords = books.fold(0, (sum, book) {
      return sum +
          book
              .findAllElements('VERS')
              .fold(0, (sum, verse) => sum + verse.text.split(' ').length);
    });
    int totalLetters = books.fold(0, (sum, book) {
      return sum +
          book.findAllElements('VERS').fold(
              0, (sum, verse) => sum + verse.text.replaceAll(' ', '').length);
    });

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: GridView.count(
        crossAxisCount: 2,
        mainAxisSpacing: 20,
        crossAxisSpacing: 20,
        children: [
          _buildStatCard('Total Books', totalBooks.toString(), Icons.book),
          _buildStatCard(
              'Total Chapters', totalChapters.toString(), Icons.menu_book),
          _buildStatCard(
              'Total Verses', totalVerses.toString(), Icons.format_quote),
          _buildStatCard(
              'Total Words', totalWords.toString(), Icons.text_fields),
          _buildStatCard(
              'Total Letters', totalLetters.toString(), Icons.text_format),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon) {
    return Card(
      color: AppColors.secondaryColor.withOpacity(0.8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: AppColors.accentColor),
            SizedBox(height: 10),
            Text(title,
                style: TextStyle(
                    fontSize: 18,
                    color: isDarkTheme
                        ? AppColors.darkTextColor
                        : AppColors.lightAccentTextColor,
                    fontWeight: FontWeight.w600)),
            SizedBox(height: 5),
            Text(value,
                style: TextStyle(
                    fontSize: 22,
                    color: isDarkTheme
                        ? AppColors.darkTextColor
                        : AppColors.lightAccentTextColor,
                    fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget booksTab() {
    if (books.isEmpty) {
      return Center(
        child: Text(
          'No Bible Version Loaded.',
          style: TextStyle(
              color: isDarkTheme
                  ? AppColors.darkAccentTextColor
                  : AppColors.lightAccentTextColor,
              fontSize: 18),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: books.length,
      itemBuilder: (context, index) {
        var book = books[index];
        var chapters = book.findAllElements('CHAPTER').length;
        var verses = book.findAllElements('VERS').length;
        bool isSelected = currentBookIndex == index;
        return Card(
          color: isSelected
              ? AppColors.accentColor.withOpacity(0.8)
              : AppColors.secondaryColor.withOpacity(0.8),
          margin: const EdgeInsets.symmetric(vertical: 8),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: ExpansionTile(
            key: Key(book.getAttribute('bname') ?? 'Unknown Book'),
            initiallyExpanded: isSelected,
            leading: CircleAvatar(
              backgroundColor: AppColors.accentColor,
              child: Icon(
                Icons.book,
                color: isDarkTheme
                    ? AppColors.darkIconColor
                    : AppColors.lightIconColor,
              ),
            ),
            title: Text(
              bibleName == 'Combined'
                  ? '${book.getAttribute('bname_en') ?? 'Unknown Book'} / ${book.getAttribute('bname_ta') ?? 'Unknown Book'}'
                  : (bibleName == 'Tamil Bible'
                      ? '${book.getAttribute('bname') ?? 'Unknown Book'}'
                      : '${book.getAttribute('bname')}'),
              style: TextStyle(
                  fontSize: 18,
                  color: isDarkTheme
                      ? AppColors.darkBibleNameColor
                      : AppColors.lightBibleNameColor,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal),
            ),
            subtitle: Text('Chapters: $chapters, Verses: $verses',
                style: TextStyle(color: AppColors.white70, fontSize: 14)),
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: chapters,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 1,
                  ),
                  itemBuilder: (context, chapterIndex) {
                    return GestureDetector(
                      onTap: () {
                        loadBook(index);
                        loadChapter(chapterIndex);
                        _onItemTapped(3); // Switch to Chapter Details page
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: AppGradients.tileGradient,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            '${chapterIndex + 1}',
                            style: TextStyle(
                                fontSize: 18,
                                color: AppColors.lightTextColor,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget chapterDetailsTab() {
    if (books.isEmpty) {
      return Center(
        child: Text(
          'No Bible Version Loaded.',
          style: TextStyle(
              color: isDarkTheme
                  ? AppColors.darkAccentTextColor
                  : AppColors.lightAccentTextColor,
              fontSize: 18),
        ),
      );
    }

    // Determine the version label for display
    String versionLabel;
    if (bibleName == 'Combined') {
      versionLabel = 'NKJV'; // Assuming 'NKJV' is the English part
    } else {
      versionLabel = bibleName;
    }

    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(
          '$selectedBookName - $selectedChapterDisplay',
          style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: isDarkTheme
                  ? AppColors.darkAccentTextColor
                  : AppColors.lightAccentTextColor),
        ),
      ),
      _buildNavigationButtons(),
      Expanded(
          child: GestureDetector(
              // Handle swipe gestures for chapter navigation
              onHorizontalDragEnd: (details) {
                if (details.primaryVelocity != null) {
                  if (details.primaryVelocity! < -200) {
                    // User swiped Left to go to Next Chapter
                    _goToNextChapter();
                  } else if (details.primaryVelocity! > 200) {
                    // User swiped Right to go to Previous Chapter
                    _goToPreviousChapter();
                  }
                }
              },
              child: Theme(
                data: Theme.of(context).copyWith(
                  textSelectionTheme: TextSelectionThemeData(
                    selectionColor: Colors.blue.withOpacity(0.3),
                    selectionHandleColor: AppColors.accentColor,
                  ),
                ),
                child: ListView.builder(
                  controller: _chapterScrollController,
                  padding: EdgeInsets.all(8.0),
                  itemCount: books[currentBookIndex]
                      .findAllElements('CHAPTER')
                      .elementAt(currentChapterIndex)
                      .findAllElements('VERS')
                      .length,
                  itemBuilder: (context, index) {
                    var chapter = books[currentBookIndex]
                        .findAllElements('CHAPTER')
                        .elementAt(currentChapterIndex);
                    var verse =
                        chapter.findAllElements('VERS').elementAt(index);
                    String verseNumber = verse.getAttribute('vnumber') ?? '';
                    String verseText = '';
                    String tamilVerseText = '';
                    String language = "en-US"; // Default language

                    if (bibleName == 'Combined') {
                      verseText = verse.findElements('EN').isNotEmpty
                          ? verse.findElements('EN').first.text.trim()
                          : '';
                      tamilVerseText = verse.findElements('TA').isNotEmpty
                          ? verse.findElements('TA').first.text.trim()
                          : '';
                      // language is handled separately
                    } else if (bibleName == 'Tamil Bible') {
                      verseText = verse.text.trim();
                      language = "ta-IN"; // Tamil
                    } else {
                      verseText = verse.text.trim();
                      language = "en-US"; // Default to English
                    }
                    String reference =
                        '$selectedBookName $selectedChapterNumber:$verseNumber';
                    bool isBookmarked =
                        bookmarkedReferences.contains(reference);
                    bool isHighlighted = highlightedReference == reference;

                    return GestureDetector(
                      onLongPress: () {
                        showModalBottomSheet(
                          context: context,
                          backgroundColor: isDarkTheme
                              ? AppColors.darkPrimaryColor
                              : AppColors.secondaryColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(25.0),
                            ),
                          ),
                          builder: (context) {
                            return Container(
                              padding: EdgeInsets.all(20),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  // Copy Button
                                  IconButton(
                                    icon: Icon(Icons.copy,
                                        color: AppColors.lightTextColor),
                                    onPressed: () {
                                      String copyText;
                                      if (bibleName == 'Combined') {
                                        // Extract English and Tamil Book Names
                                        List<String> bookNames =
                                            selectedBookName.split(' / ');
                                        String enBookName = bookNames.isNotEmpty
                                            ? bookNames[0]
                                            : 'Unknown Book';
                                        String taBookName = bookNames.length > 1
                                            ? bookNames[1]
                                            : 'Unknown Book';

                                        copyText = '''
$enBookName $selectedChapterNumber:$verseNumber
NKJV: $verseText
தமிழ்: $tamilVerseText
''';
                                      } else if (bibleName == 'Tamil Bible') {
                                        copyText = '''
$selectedBookName $selectedChapterNumber:$verseNumber
$verseText
''';
                                      } else {
                                        copyText = '''
$bibleName $selectedBookName $selectedChapterNumber:$verseNumber
$verseText
''';
                                      }

                                      Clipboard.setData(
                                          ClipboardData(text: copyText));
                                      Navigator.pop(context);
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content:
                                                Text('Copied to clipboard')),
                                      );
                                    },
                                  ),
                                  // Bookmark Button
                                  IconButton(
                                    icon: Icon(
                                        isBookmarked
                                            ? Icons.bookmark
                                            : Icons.bookmark_border,
                                        color: AppColors.lightTextColor),
                                    onPressed: () {
                                      if (isBookmarked) {
                                        removeReference(reference);
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                              content: Text(
                                                  'Removed from bookmarks')),
                                        );
                                      } else {
                                        saveReference(reference);
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                              content:
                                                  Text('Saved to bookmarks')),
                                        );
                                      }
                                      Navigator.pop(context);
                                    },
                                  ),
                                  // Share Button
                                  IconButton(
                                    icon: Icon(Icons.share,
                                        color: AppColors.lightTextColor),
                                    onPressed: () {
                                      String shareText;
                                      if (bibleName == 'Combined') {
                                        shareText =
                                            'NKJV $reference: $verseText\nதமிழ்: $tamilVerseText';
                                      } else if (bibleName == 'Tamil Bible') {
                                        shareText = '$reference: $verseText';
                                      } else {
                                        shareText =
                                            '$bibleName $reference: $verseText';
                                      }
                                      Share.share(shareText);
                                      Navigator.pop(context);
                                    },
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                      },
                      onTap: () {
                        setState(() {
                          if (highlightedReference == reference) {
                            highlightedReference = null;
                          } else {
                            highlightedReference = reference;
                            _scrollToVerse(reference);
                          }
                        });
                      },
                      child: Container(
                        key: isHighlighted ? Key('verse_$index') : null,
                        padding: EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 4.0),
                        margin: EdgeInsets.symmetric(vertical: 4.0),
                        decoration: BoxDecoration(
                          color: isHighlighted
                              ? Colors.blue.withOpacity(0.3)
                              : isBookmarked
                                  ? Colors.blue.withOpacity(0.3)
                                  : Colors.transparent,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (bibleName == 'Combined') ...[
                              Row(
                                children: [
                                  Text(
                                    'NKJV ',
                                    style: TextStyle(
                                      color: AppColors.secondaryColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: isHighlighted ? 20 : fontSize,
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      Icons.volume_up,
                                      size: 20,
                                      color: AppColors.accentColor,
                                    ),
                                    onPressed: () {
                                      _speak(verseText, 'en-US');
                                    },
                                  ),
                                ],
                              ),
                              SizedBox(height: 2),
                              Text(
                                '$verseNumber: $verseText',
                                style: TextStyle(
                                  color: isDarkTheme
                                      ? AppColors.darkTextColor
                                      : AppColors.lightTextColor,
                                  fontSize: isHighlighted ? 20 : fontSize,
                                ),
                              ),
                              SizedBox(height: 10),
                              Row(
                                children: [
                                  Text(
                                    'தமிழ் ',
                                    style: TextStyle(
                                      color: AppColors.secondaryColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize:
                                          isHighlighted ? 18 : fontSize - 2,
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      Icons.volume_up,
                                      size: 20,
                                      color: AppColors.accentColor,
                                    ),
                                    onPressed: () {
                                      _speak(tamilVerseText, 'ta-IN');
                                    },
                                  ),
                                ],
                              ),
                              SizedBox(height: 2),
                              Text(
                                '$verseNumber: $tamilVerseText',
                                style: TextStyle(
                                  color: isDarkTheme
                                      ? AppColors.darkTextColor
                                      : AppColors.lightTextColor,
                                  fontSize: isHighlighted ? 18 : fontSize - 2,
                                ),
                              ),
                            ] else if (bibleName == 'Tamil Bible') ...[
                              Row(
                                children: [
                                  Text(
                                    'Tamil ',
                                    style: TextStyle(
                                      color: AppColors.secondaryColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: isHighlighted ? 20 : fontSize,
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      Icons.volume_up,
                                      size: 20,
                                      color: AppColors.accentColor,
                                    ),
                                    onPressed: () {
                                      _speak(verseText, 'ta-IN');
                                    },
                                  ),
                                ],
                              ),
                              SizedBox(height: 2),
                              Text(
                                '$verseNumber: $verseText',
                                style: TextStyle(
                                  color: isDarkTheme
                                      ? AppColors.darkTextColor
                                      : AppColors.lightTextColor,
                                  fontSize: isHighlighted ? 20 : fontSize,
                                ),
                              ),
                            ] else ...[
                              Row(
                                children: [
                                  Text(
                                    '$versionLabel ',
                                    style: TextStyle(
                                      color: AppColors.secondaryColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: isHighlighted ? 20 : fontSize,
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(
                                      Icons.volume_up,
                                      size: 20,
                                      color: AppColors.accentColor,
                                    ),
                                    onPressed: () {
                                      _speak(verseText, 'en-US');
                                    },
                                  ),
                                ],
                              ),
                              SizedBox(height: 2),
                              Text(
                                '$verseNumber: $verseText',
                                style: TextStyle(
                                  color: isDarkTheme
                                      ? AppColors.darkTextColor
                                      : AppColors.lightTextColor,
                                  fontSize: isHighlighted ? 20 : fontSize,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                ),
              )))
    ]);
  }

  void _toggleBookmark(String reference, bool isBookmarked) {
    if (isBookmarked) {
      removeReference(reference);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Verse removed from bookmarks')),
      );
    } else {
      saveReference(reference);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Verse saved to bookmarks')),
      );
    }
  }

  Widget _buildNavigationButtons() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Previous Book Button - Left
          CircleAvatar(
            backgroundColor: AppColors.accentColor,
            child: IconButton(
              icon: Icon(Icons.skip_previous,
                  color: isDarkTheme
                      ? AppColors.darkIconColor
                      : const Color.fromARGB(255, 255, 255, 255)),
              onPressed: _canGoToPreviousBook()
                  ? () {
                      _goToPreviousBook();
                    }
                  : null,
            ),
          ),
          // Previous Chapter Button - Left Arrow
          CircleAvatar(
            backgroundColor: AppColors.accentColor,
            child: IconButton(
              icon: Icon(Icons.arrow_back,
                  color: isDarkTheme
                      ? AppColors.darkIconColor
                      : const Color.fromARGB(255, 255, 255, 255)),
              onPressed: _canGoToPreviousChapter()
                  ? () {
                      _goToPreviousChapter();
                    }
                  : null,
            ),
          ),
          // Next Chapter Button - Right Arrow
          CircleAvatar(
            backgroundColor: AppColors.accentColor,
            child: IconButton(
              icon: Icon(Icons.arrow_forward,
                  color: isDarkTheme
                      ? AppColors.darkIconColor
                      : const Color.fromARGB(255, 255, 255, 255)),
              onPressed: _canGoToNextChapter()
                  ? () {
                      _goToNextChapter();
                    }
                  : null,
            ),
          ),
          // Next Book Button - Right
          CircleAvatar(
            backgroundColor: AppColors.accentColor,
            child: IconButton(
              icon: Icon(Icons.skip_next,
                  color: isDarkTheme
                      ? AppColors.darkIconColor
                      : const Color.fromARGB(255, 255, 255, 255)),
              onPressed: _canGoToNextBook()
                  ? () {
                      _goToNextBook();
                    }
                  : null,
            ),
          ),
        ],
      ),
    );
  }

  bool _canGoToPreviousBook() {
    return currentBookIndex > 0;
  }

  bool _canGoToNextBook() {
    return currentBookIndex < books.length - 1;
  }

  void _goToPreviousBook() {
    if (_canGoToPreviousBook()) {
      loadBook(currentBookIndex - 1);
      loadChapter(0); // Load the first chapter of the new book
      setState(() {
        _selectedIndex = 3; // Navigate to Chapter Details page
        highlightedReference = null; // Reset highlighted reference
      });
    }
  }

  void _goToNextBook() {
    if (_canGoToNextBook()) {
      loadBook(currentBookIndex + 1);
      loadChapter(0); // Load the first chapter of the new book
      setState(() {
        _selectedIndex = 3; // Navigate to Chapter Details page
        highlightedReference = null; // Reset highlighted reference
      });
    }
  }

  bool _canGoToPreviousChapter() {
    return currentChapterIndex > 0;
  }

  bool _canGoToNextChapter() {
    return currentChapterIndex < totalChapters - 1;
  }

  void _goToPreviousChapter() {
    if (_canGoToPreviousChapter()) {
      loadChapter(currentChapterIndex - 1);
      setState(() {
        highlightedReference = null; // Reset highlighted reference
      });
    }
  }

  void _goToNextChapter() {
    if (_canGoToNextChapter()) {
      loadChapter(currentChapterIndex + 1);
      setState(() {
        highlightedReference = null; // Reset highlighted reference
      });
    }
  }
}

class BibleVersion {
  final String name;
  final String filePath;

  BibleVersion({required this.name, required this.filePath});
}
