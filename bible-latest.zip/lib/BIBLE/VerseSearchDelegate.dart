// lib/bible/verse_search_delegate.dart

import 'package:bible/BIBLE/BibleReaderHome.dart';
import 'package:flutter/material.dart';
import 'package:xml/xml.dart' as xml;
import 'package:speech_to_text/speech_to_text.dart' as stt;

class VerseSearchDelegate extends SearchDelegate<String> {
  final List<xml.XmlElement> books;
  final Function(String) onSaveReference;
  final String bibleName;
  final double fontSize;
  final Color fontColor;
  final Function(String) onNavigateToVerse;
  final bool isDarkTheme;

  late stt.SpeechToText _speech;
  bool _isListeningEnglish = false;
  bool _isListeningTamil = false;
  String _currentLanguage = 'en_US';
  bool _isSpeechActive = false;

  VerseSearchDelegate({
    required this.books,
    required this.onSaveReference,
    required this.bibleName,
    required this.fontSize,
    required this.fontColor,
    required this.onNavigateToVerse,
    required this.isDarkTheme,
  }) {
    _speech = stt.SpeechToText();
  }

  @override
  String get searchFieldLabel => 'Search Verses';

  @override
  TextStyle? get searchFieldStyle => TextStyle(color: fontColor, fontSize: 16);

  @override
  ThemeData appBarTheme(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return theme.copyWith(
      primaryColor:
          isDarkTheme ? AppColors.darkPrimaryColor : AppColors.secondaryColor,
      primaryIconTheme: theme.primaryIconTheme.copyWith(
        color: Colors.white, // Set icons to white
      ),
      textTheme: TextTheme(
        titleLarge: searchFieldStyle ?? theme.textTheme.titleLarge,
      ),
      inputDecorationTheme: InputDecorationTheme(
        hintStyle: searchFieldStyle,
        border: InputBorder.none,
      ),
    );
  }

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      if (query.isNotEmpty)
        IconButton(
          icon: const Icon(Icons.clear, color: Colors.white),
          onPressed: () {
            query = '';
            showSuggestions(context);
          },
        ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back, color: Colors.white),
      onPressed: () {
        close(context, '');
      },
    );
  }

  void _showListeningDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor:
            isDarkTheme ? Colors.grey[800] : AppColors.secondaryColor,
        title: Row(
          children: const [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppColors.accentColor),
            ),
            SizedBox(width: 20),
            Text(
              'Listening...',
              style: TextStyle(
                color: AppColors.lightTextColor,
                fontSize: 18,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              _stopListening();
              Navigator.of(context).pop();
              if (query.isNotEmpty) {
                showResults(context);
              }
            },
            child: const Text(
              'Stop',
              style: TextStyle(
                color: AppColors.accentColor,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _stopListening() {
    if (_isListeningEnglish || _isListeningTamil) {
      _speech.stop();
      _isListeningEnglish = false;
      _isListeningTamil = false;
      _isSpeechActive = false;
    }
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // Centered mic buttons with labels
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Select Language to Search',
              style: TextStyle(
                fontSize: 20,
                color: isDarkTheme
                    ? AppColors.darkTextColor
                    : AppColors.lightTextColor,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Search in English
                Column(
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accentColor,
                        shape: const CircleBorder(),
                        padding: const EdgeInsets.all(20),
                      ),
                      child: Icon(
                        _isListeningEnglish ? Icons.mic : Icons.mic_none,
                        color: Colors.white,
                        size: 30,
                      ),
                      onPressed: () async {
                        if (!_isListeningEnglish && !_isListeningTamil) {
                          bool available = await _speech.initialize(
                            onStatus: (val) {
                              if (val == 'done' || val == 'notListening') {
                                _isListeningEnglish = false;
                                _isSpeechActive = false;
                                Navigator.of(context).pop();
                                if (query.isNotEmpty) {
                                  showResults(context);
                                }
                              }
                            },
                            onError: (val) {
                              _isListeningEnglish = false;
                              _isSpeechActive = false;
                              Navigator.of(context).pop();
                              showSuggestions(context);
                            },
                          );
                          if (available) {
                            _isListeningEnglish = true;
                            _currentLanguage = 'en_US';
                            _isSpeechActive = true;
                            _speech.listen(
                              localeId: _currentLanguage,
                              onResult: (val) {
                                query = val.recognizedWords;
                              },
                            );
                            _showListeningDialog(context);
                          }
                        } else {
                          _isListeningEnglish = false;
                          _speech.stop();
                          _isSpeechActive = false;
                          Navigator.of(context).pop();
                          if (query.isNotEmpty) {
                            showResults(context);
                          }
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Search in English',
                      style: TextStyle(
                        fontSize: 16,
                        color: isDarkTheme
                            ? AppColors.darkTextColor
                            : AppColors.lightTextColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 60),
                // Search in Tamil
                Column(
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accentColor,
                        shape: const CircleBorder(),
                        padding: const EdgeInsets.all(20),
                      ),
                      child: Icon(
                        _isListeningTamil ? Icons.mic : Icons.mic_none,
                        color: Colors.white,
                        size: 30,
                      ),
                      onPressed: () async {
                        if (!_isListeningEnglish && !_isListeningTamil) {
                          bool available = await _speech.initialize(
                            onStatus: (val) {
                              if (val == 'done' || val == 'notListening') {
                                _isListeningTamil = false;
                                _isSpeechActive = false;
                                Navigator.of(context).pop();
                                if (query.isNotEmpty) {
                                  showResults(context);
                                }
                              }
                            },
                            onError: (val) {
                              _isListeningTamil = false;
                              _isSpeechActive = false;
                              Navigator.of(context).pop();
                              showSuggestions(context);
                            },
                          );
                          if (available) {
                            _isListeningTamil = true;
                            _currentLanguage = 'ta_IN';
                            _isSpeechActive = true;
                            _speech.listen(
                              localeId: _currentLanguage,
                              onResult: (val) {
                                query = val.recognizedWords;
                              },
                            );
                            _showListeningDialog(context);
                          }
                        } else {
                          _isListeningTamil = false;
                          _speech.stop();
                          _isSpeechActive = false;
                          Navigator.of(context).pop();
                          if (query.isNotEmpty) {
                            showResults(context);
                          }
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'தேடல் தமிழில்',
                      style: TextStyle(
                        fontSize: 16,
                        color: isDarkTheme
                            ? AppColors.darkTextColor
                            : AppColors.lightTextColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            if (_isSpeechActive)
              Padding(
                padding: const EdgeInsets.only(top: 30),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      valueColor: const AlwaysStoppedAnimation<Color>(
                          AppColors.accentColor),
                    ),
                    const SizedBox(width: 20),
                    Text(
                      'Listening...',
                      style: TextStyle(
                        fontSize: 18,
                        color: isDarkTheme
                            ? AppColors.darkTextColor
                            : AppColors.lightTextColor,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    List<Map<String, String>> searchResults = [];
    int totalOccurrences = 0;
    Map<String, Map<String, List<Map<String, String>>>> bookChapterOccurrences =
        {};

    if (query.isNotEmpty) {
      searchResults = _processSearchResults(query);
      totalOccurrences = searchResults.length;
      for (var result in searchResults) {
        String book = result['book']!;
        String chapter = result['chapter']!;
        if (!bookChapterOccurrences.containsKey(book)) {
          bookChapterOccurrences[book] = {};
        }
        if (!bookChapterOccurrences[book]!.containsKey(chapter)) {
          bookChapterOccurrences[book]![chapter] = [];
        }
        bookChapterOccurrences[book]![chapter]!.add(result);
      }
    }

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          // Search Summary without box
          if (query.isNotEmpty)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Search Summary',
                  style: TextStyle(
                    fontSize: 20,
                    color: isDarkTheme
                        ? AppColors.darkTextColor
                        : AppColors.lightTextColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Total Occurrences: $totalOccurrences',
                  style: TextStyle(
                    fontSize: 18,
                    color: isDarkTheme
                        ? AppColors.darkTextColor
                        : AppColors.lightTextColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          Expanded(
            child: searchResults.isNotEmpty
                ? ListView.builder(
                    padding: const EdgeInsets.all(0),
                    itemCount: bookChapterOccurrences.keys.length,
                    itemBuilder: (context, index) {
                      String book =
                          bookChapterOccurrences.keys.elementAt(index);
                      Map<String, List<Map<String, String>>> chapters =
                          bookChapterOccurrences[book]!;
                      int bookCount = chapters.values
                          .fold(0, (sum, verses) => sum + verses.length);
                      return Card(
                        color: isDarkTheme
                            ? Colors.grey[850]
                            : AppColors.secondaryColor.withAlpha(220),
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20)),
                        elevation: 5,
                        child: ExpansionTile(
                          leading: const Icon(
                            Icons.book,
                            color: AppColors.accentColor,
                          ),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  book,
                                  style: TextStyle(
                                    color: AppColors.lightTextColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  color: AppColors.accentColor,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  '$bookCount',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          children: chapters.keys.map((chapter) {
                            List<Map<String, String>> verses =
                                chapters[chapter]!;
                            int chapterCount = verses.length;
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16.0),
                              child: ExpansionTile(
                                leading: const Icon(
                                  Icons.bookmark_border,
                                  color: AppColors.accentColor,
                                ),
                                title: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                        'Chapter $chapter',
                                        style: TextStyle(
                                          color: AppColors.lightTextColor,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: AppColors.accentColor,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        '$chapterCount',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                children: verses.map((verse) {
                                  String verseRef =
                                      '${verse['book']} ${verse['chapter']}:${verse['verseNumber']}';
                                  String verseText = verse['verseText']!;
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 6.0, horizontal: 8.0),
                                    child: Card(
                                      color: isDarkTheme
                                          ? Colors.grey[700]
                                          : Colors.grey[300],
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      child: ListTile(
                                        title: RichText(
                                          text: TextSpan(
                                            children: _highlightOccurrences(
                                                verseText, query),
                                            style: TextStyle(
                                              color: AppColors.lightTextColor,
                                              fontSize: fontSize,
                                            ),
                                          ),
                                        ),
                                        subtitle: Text(
                                          verseRef,
                                          style: TextStyle(
                                            color: AppColors.accentColor,
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        trailing: IconButton(
                                          icon: const Icon(Icons.bookmark,
                                              color: AppColors.accentColor),
                                          onPressed: () {
                                            onSaveReference(verseRef);
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              SnackBar(
                                                  content:
                                                      Text('Saved $verseRef')),
                                            );
                                          },
                                        ),
                                        onTap: () {
                                          onNavigateToVerse(verseRef);
                                          close(context, '');
                                        },
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ),
                            );
                          }).toList(),
                        ),
                      );
                    },
                  )
                : Center(
                    child: Text(
                      query.isEmpty
                          ? 'Start typing to find verses.'
                          : 'No results found.',
                      style: TextStyle(color: AppColors.white70, fontSize: 18),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  List<TextSpan> _highlightOccurrences(String source, String query) {
    if (query.isEmpty) {
      return [TextSpan(text: source)];
    }
    var matches = <Match>[];
    String lowerSource = source.toLowerCase();
    String lowerQuery = query.toLowerCase();
    int start = 0;
    while (true) {
      final match = lowerSource.indexOf(lowerQuery, start);
      if (match == -1) break;
      matches.add(Match(match, match + query.length));
      start = match + query.length;
    }

    if (matches.isEmpty) {
      return [TextSpan(text: source)];
    }

    List<TextSpan> spans = [];
    int currentIndex = 0;
    for (var match in matches) {
      if (match.start > currentIndex) {
        spans.add(TextSpan(text: source.substring(currentIndex, match.start)));
      }
      spans.add(TextSpan(
          text: source.substring(match.start, match.end),
          style: const TextStyle(
            backgroundColor: Colors.yellow,
          )));
      currentIndex = match.end;
    }
    if (currentIndex < source.length) {
      spans.add(TextSpan(text: source.substring(currentIndex)));
    }
    return spans;
  }

  List<Map<String, String>> _processSearchResults(String query) {
    List<Map<String, String>> searchResults = [];
    if (query.isEmpty) return searchResults;

    String lowerQuery = query.toLowerCase();

    for (var book in books) {
      String bookName = bibleName == 'Combined'
          ? '${book.getAttribute('bname_en') ?? ''} / ${book.getAttribute('bname_ta') ?? ''}'
          : (bibleName == 'Tamil Bible'
              ? '${book.getAttribute('bname') ?? ''}'
              : (book.getAttribute('bname') ?? ''));
      for (var chapter in book.findAllElements('CHAPTER')) {
        String chapterNumber = chapter.getAttribute('cnumber') ?? '';
        for (var verse in chapter.findAllElements('VERS')) {
          String verseNumber = verse.getAttribute('vnumber') ?? '';
          String verseText = verse.innerText.trim();
          if (verseText.toLowerCase().contains(lowerQuery)) {
            searchResults.add({
              'book': bookName,
              'chapter': chapterNumber,
              'verseNumber': verseNumber,
              'verseText': verseText,
            });
          }
        }
      }
    }

    return searchResults;
  }
}

class Match {
  final int start;
  final int end;

  Match(this.start, this.end);
}

class AppColors {
  // Light Theme Colors
  static const Color lightTextColor = Colors.black;
  static const Color lightBibleNameColor =
      Color.fromARGB(255, 5, 5, 5); // Dark Text
  static const Color lightIconColor = Color(0xFF2196F3); // Blue

  // Dark Theme Colors
  static const Color darkTextColor = Color.fromARGB(255, 255, 255, 255);
  static const Color darkBibleNameColor = Colors.white;
  static const Color darkIconColor = Colors.white;

  // Common Colors
  static const Color secondaryColor = Color(0xFF2196F3); // Light Blue
  static const Color accentColor = Color(0xFF1976D2); // Darker Blue
  static const Color darkPrimaryColor =
      Color(0xFF0D47A1); // Dark Blue for dark theme
  static const Color overlayColor = Colors.grey; // For overlays
  static const Color white70 = Colors.white70;
  static const Color titleLargeColor = Color(0xFF2196F3);

  static const Color darkAccentTextColor = Colors.white;
  static const Color lightAccentTextColor = Color.fromARGB(255, 2, 5, 46);
}
