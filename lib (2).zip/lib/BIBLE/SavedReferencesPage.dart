
import 'package:flutter/material.dart';
import 'package:bible/BIBLE/BibleReaderHome.dart'; // Adjust the import path as needed

class SavedReferencesPage extends StatelessWidget {
  final List<Map<String, String>> savedReferences;
  final Function(String) getVerseDetails;
  final Function(String) onGoToVerse;
  final bool isDarkTheme;

  SavedReferencesPage(
      {required this.savedReferences,
      required this.getVerseDetails,
      required this.onGoToVerse,
      required this.isDarkTheme});

  @override
  Widget build(BuildContext context) {
    if (savedReferences.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Saved References',
              style: TextStyle(
                  color: isDarkTheme
                      ? AppColors.darkTextColor
                      : AppColors.lightTextColor)),
          backgroundColor: AppColors.secondaryColor,
        ),
        body: Center(
          child: Text(
            'No bookmarks saved.',
            style: TextStyle(
                color: isDarkTheme
                    ? AppColors.darkTextColor
                    : AppColors.lightTextColor,
                fontSize: 18),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Saved References',
            style: TextStyle(
                color: isDarkTheme
                    ? AppColors.darkTextColor
                    : AppColors.lightTextColor)),
        backgroundColor: AppColors.secondaryColor,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: savedReferences.length,
        itemBuilder: (context, index) {
          return Card(
            color: AppColors.secondaryColor.withOpacity(0.8),
            margin: const EdgeInsets.symmetric(vertical: 8),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: AppColors.accentColor,
                child: Icon(
                  Icons.bookmark,
                  color: isDarkTheme
                      ? AppColors.darkIconColor
                      : AppColors.lightIconColor,
                ),
              ),
              title: Text(savedReferences[index]['reference']!,
                  style: TextStyle(
                      color: isDarkTheme
                          ? AppColors.darkTextColor
                          : AppColors.lightTextColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 18)),
              subtitle: Text('Saved on: ${savedReferences[index]['date']}',
                  style: TextStyle(color: AppColors.white70, fontSize: 14)),
              trailing: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.accentColor,
                ),
                child: Text('Go to Verse'),
                onPressed: () {
                  onGoToVerse(savedReferences[index]['reference']!);
                },
              ),
              onTap: () {
                String reference = savedReferences[index]['reference']!;
                String verseDetails = getVerseDetails(reference);
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Verse Details',
                          style: TextStyle(
                              color: isDarkTheme
                                  ? AppColors.darkTextColor
                                  : AppColors.lightTextColor)),
                      content: Text(verseDetails,
                          style: TextStyle(
                              color: isDarkTheme
                                  ? AppColors.darkTextColor
                                  : AppColors.lightTextColor)),
                      backgroundColor: AppColors.secondaryColor,
                      actions: [
                        TextButton(
                          child: Text('Close',
                              style: TextStyle(color: AppColors.accentColor)),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }
}
