// lib/BIBLE/SettingsPage.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Define AppColors to manage theme-based colors
class AppColors {
  // Light Theme Colors
  static const Color lightBackground = Colors.white;
  static const Color lightCard = Colors.white;
  static const Color lightText = Colors.black;
  static const Color lightIcon = Color(0xFF2196F3); // Blue

  // Dark Theme Colors
  static const Color darkBackground = Color(0xFF121212);
  static const Color darkCard = Color(0xFF1E1E1E);
  static const Color darkText = Colors.white;
  static const Color darkIcon = Colors.white;

  // Common Colors
  static const Color secondaryColor = Color(0xFF2196F3); // Light Blue
  static const Color accentColor = Color(0xFF1976D2); // Darker Blue
  static const Color overlayColor = Colors.grey; // For overlays
  static const Color white70 = Colors.white70;
}

class AppGradients {
  static const LinearGradient lightThemeGradient = LinearGradient(
    colors: [
      AppColors.lightBackground, // White
      AppColors.secondaryColor, // Light Blue
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient darkThemeGradient = LinearGradient(
    colors: [
      AppColors.darkBackground, // Dark Background
      AppColors.secondaryColor, // Light Blue
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class SettingsPage extends StatefulWidget {
  final double fontSize;
  final bool isDarkTheme;
  final Function(double) onFontSizeChanged;
  final Function(bool) onThemeChanged;

  SettingsPage({
    required this.fontSize,
    required this.isDarkTheme,
    required this.onFontSizeChanged,
    required this.onThemeChanged,
  });

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late double _fontSize;
  late bool _isDarkTheme;

  // Define the minimum and maximum font sizes
  final double _minFontSize = 12.0;
  final double _maxFontSize = 30.0;

  @override
  void initState() {
    super.initState();
    _fontSize = widget.fontSize;
    _isDarkTheme = widget.isDarkTheme;
  }

  @override
  Widget build(BuildContext context) {
    // Determine current theme colors
    Color backgroundColor =
        _isDarkTheme ? AppColors.darkBackground : AppColors.lightBackground;
    Color cardColor = _isDarkTheme ? AppColors.darkCard : AppColors.lightCard;
    Color textColor = _isDarkTheme ? AppColors.darkText : AppColors.lightText;
    Color iconColor = _isDarkTheme ? AppColors.darkIcon : AppColors.lightIcon;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Settings',
          style: TextStyle(
            color: textColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor:
            _isDarkTheme ? AppColors.darkBackground : AppColors.secondaryColor,
        elevation: 0,
        iconTheme: IconThemeData(
          color: iconColor,
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: _isDarkTheme
              ? AppGradients.darkThemeGradient
              : AppGradients.lightThemeGradient,
        ),
        child: ListView(
          padding: const EdgeInsets.all(16.0),
          children: <Widget>[
            // Font Size Card
            Card(
              color: cardColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 16.0, horizontal: 12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header with Icon and Title
                    Row(
                      children: [
                        Icon(
                          Icons.text_fields,
                          color: AppColors.accentColor,
                          size: 30,
                        ),
                        SizedBox(width: 10),
                        Text(
                          'Font Size',
                          style: TextStyle(
                            color: textColor,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    // Font Size Slider
                    Row(
                      children: [
                        IconButton(
                          icon: Icon(Icons.remove_circle_outline,
                              color: AppColors.accentColor),
                          onPressed: _fontSize > _minFontSize
                              ? () {
                                  setState(() {
                                    _fontSize -= 1;
                                  });
                                  widget.onFontSizeChanged(_fontSize);
                                }
                              : null,
                        ),
                        Expanded(
                          child: Slider(
                            value: _fontSize,
                            min: _minFontSize,
                            max: _maxFontSize,
                            divisions: (_maxFontSize - _minFontSize).toInt(),
                            label: _fontSize.toInt().toString(),
                            activeColor: AppColors.accentColor,
                            inactiveColor: AppColors.overlayColor,
                            onChanged: (double value) {
                              setState(() {
                                _fontSize = value;
                              });
                              widget.onFontSizeChanged(value);
                            },
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.add_circle_outline,
                              color: AppColors.accentColor),
                          onPressed: _fontSize < _maxFontSize
                              ? () {
                                  setState(() {
                                    _fontSize += 1;
                                  });
                                  widget.onFontSizeChanged(_fontSize);
                                }
                              : null,
                        ),
                      ],
                    ),
                    Center(
                      child: Text(
                        '${_fontSize.toInt()}',
                        style: TextStyle(
                          color: textColor,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            // Theme Toggle Card
            Card(
              color: cardColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 16.0, horizontal: 12.0),
                child: ListTile(
                  leading: Icon(
                    Icons.brightness_6,
                    color: AppColors.accentColor,
                    size: 30,
                  ),
                  title: Text(
                    'Dark Theme',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Switch(
                    value: _isDarkTheme,
                    activeColor: AppColors.accentColor,
                    inactiveThumbColor: AppColors.accentColor,
                    onChanged: (bool value) {
                      setState(() {
                        _isDarkTheme = value;
                      });
                      widget.onThemeChanged(value);
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
