// lib/bible/verse_search_delegate.dart

import 'package:bible/BIBLE/BibleReaderHome.dart';
import 'package:flutter/material.dart';
import 'package:xml/xml.dart' as xml;
import 'package:speech_to_text/speech_to_text.dart' as stt;

class VerseSearchDelegate extends SearchDelegate {
  final List<xml.XmlElement> books;
  final Function(String) onSaveReference;
  final String bibleName;
  final double fontSize;
  final Color fontColor;
  final Function(String) onNavigateToVerse;
  final bool isDarkTheme;

  late stt.SpeechToText _speech;
  bool _isListening = false;

  VerseSearchDelegate({
    required this.books,
    required this.onSaveReference,
    required this.bibleName,
    required this.fontSize,
    required this.fontColor,
    required this.onNavigateToVerse,
    required this.isDarkTheme,
  }) {
    _speech = stt.SpeechToText();
  }

  @override
  String get searchFieldLabel => 'Search Verses';

  @override
  TextStyle? get searchFieldStyle =>
      TextStyle(color: fontColor, fontSize: 16);

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      if (query.isNotEmpty)
        IconButton(
          icon: Icon(Icons.clear, color: AppColors.accentColor),
          onPressed: () {
            query = '';
            showSuggestions(context);
          },
        ),
      IconButton(
        icon: Icon(
          _isListening ? Icons.mic : Icons.mic_none,
          color: AppColors.accentColor,
        ),
        onPressed: () async {
          if (!_isListening) {
            bool available = await _speech.initialize(
              onStatus: (val) {
                if (val == 'done') {
                  _isListening = false;
                  showSuggestions(context); // Trigger UI update
                }
              },
              onError: (val) {
                _isListening = false;
                showSuggestions(context); // Trigger UI update
              },
            );
            if (available) {
              _isListening = true;
              _speech.listen(
                onResult: (val) {
                  query = val.recognizedWords;
                  showResults(context);
                },
              );
              showSuggestions(context); // Trigger UI update
            }
          } else {
            _isListening = false;
            _speech.stop();
            showSuggestions(context); // Trigger UI update
          }
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back, color: AppColors.accentColor),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    List<Map<String, String>> searchResults = [];
    int totalOccurrences = 0;
    Map<String, int> bookOccurrences = {};

    if (query.isNotEmpty) {
      searchResults = _processSearchResults(query);
      totalOccurrences = searchResults.length;
      for (var result in searchResults) {
        String book = result['book']!;
        if (bookOccurrences.containsKey(book)) {
          bookOccurrences[book] = bookOccurrences[book]! + 1;
        } else {
          bookOccurrences[book] = 1;
        }
      }
    }

    return Column(
      children: [
        if (query.isNotEmpty)
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              color: AppColors.secondaryColor.withOpacity(0.8),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const Text(
                      'Search Summary',
                      style: TextStyle(
                          fontSize: 20,
                          color: AppColors.lightTextColor,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Total Occurrences: $totalOccurrences',
                      style: const TextStyle(
                          fontSize: 16,
                          color: AppColors.lightTextColor,
                          fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      'Occurrences per Book:',
                      style: TextStyle(
                          fontSize: 16,
                          color: AppColors.lightTextColor,
                          fontWeight: FontWeight.w600),
                    ),
                    SizedBox(
                      height: 150,
                      child: ListView(
                        children: bookOccurrences.entries.map((entry) {
                          return Text(
                            '${entry.key}: ${entry.value}',
                            style: const TextStyle(
                                fontSize: 14,
                                color: AppColors.lightTextColor,
                                fontWeight: FontWeight.w500),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        Expanded(
          child: searchResults.isNotEmpty
              ? ListView.builder(
                  padding: const EdgeInsets.all(16.0),
                  itemCount: searchResults.length,
                  itemBuilder: (context, index) {
                    var result = searchResults[index];
                    return Card(
                      color: AppColors.secondaryColor.withOpacity(0.8),
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: AppColors.accentColor,
                          child: Icon(
                            Icons.search,
                            color: AppColors.lightTextColor,
                          ),
                        ),
                        title: Text(
                          '${result['book']} ${result['chapter']}:${result['verseNumber']}',
                          style: const TextStyle(
                              color: AppColors.lightTextColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 18),
                        ),
                        subtitle: Text(
                          result['verseText']!,
                          style: TextStyle(
                            color: AppColors.lightTextColor,
                            fontSize: fontSize,
                          ),
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.bookmark,
                              color: AppColors.accentColor),
                          onPressed: () {
                            onSaveReference(
                                '${result['book']} ${result['chapter']}:${result['verseNumber']}');
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                  content: Text(
                                      'Saved ${result['book']} ${result['chapter']}:${result['verseNumber']}')),
                            );
                          },
                        ),
                        onTap: () {
                          onNavigateToVerse(
                              '${result['book']} ${result['chapter']}:${result['verseNumber']}');
                          close(context, null);
                        },
                      ),
                    );
                  },
                )
              : Center(
                  child: Text(
                    query.isEmpty
                        ? 'Start typing to find verses.'
                        : 'No results found.',
                    style:
                        const TextStyle(color: AppColors.white70, fontSize: 18),
                  ),
                ),
        ),
      ],
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // Optional: Implement suggestions if needed
    return Container();
  }

  List<Map<String, String>> _processSearchResults(String query) {
    List<Map<String, String>> searchResults = [];
    if (query.isEmpty) return searchResults;

    String lowerQuery = query.toLowerCase();

    for (var book in books) {
      String bookName = bibleName == 'Combined'
          ? '${book.getAttribute('bname_en') ?? ''} / ${book.getAttribute('bname_ta') ?? ''}'
          : (bibleName == 'Tamil Bible'
              ? '${book.getAttribute('bname') ?? ''}'
              : (book.getAttribute('bname') ?? ''));
      for (var chapter in book.findAllElements('CHAPTER')) {
        String chapterNumber = chapter.getAttribute('cnumber') ?? '';
        for (var verse in chapter.findAllElements('VERS')) {
          String verseNumber = verse.getAttribute('vnumber') ?? '';
          String verseText = verse.innerText.trim();
          if (verseText.toLowerCase().contains(lowerQuery)) {
            searchResults.add({
              'book': bookName,
              'chapter': chapterNumber,
              'verseNumber': verseNumber,
              'verseText': verseText,
            });
          }
        }
      }
    }

    return searchResults;
  }
}
